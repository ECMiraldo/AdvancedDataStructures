#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "ll.h"



typedef struct {
	int x;
	int y;
	ListElem l; //lista de ints
} Point;
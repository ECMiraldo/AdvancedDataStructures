#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ll.h"
#include "Logica.h"

ListElem ReadData(char* filename);